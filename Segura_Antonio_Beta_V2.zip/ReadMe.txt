Controls (for now):

Move: W,A,S,D
Previous Dog: Q
Next Dog: E
Jump: Spacebar
Interact: F (Not yet implemented)
Pause Menu: ESC (Not Functionnal Debug to do)
rally's gravity Might still be in Moon mode please ignore
 
